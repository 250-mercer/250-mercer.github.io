
<!DOCTYPE html>

<html data-wf-domain="wellness-cms.webflow.io" data-wf-page="5b155db3ecb0bd9ab50d2c0f" data-wf-site="5ac4f751b50fc9186ae6aeb1" class="w-mod-js w-mod-ix wf-oswald-n2-inactive wf-oswald-n3-inactive wf-oswald-n4-inactive wf-oswald-n5-inactive wf-oswald-n6-inactive wf-oswald-n7-inactive wf-roboto-n1-inactive wf-roboto-i1-inactive wf-roboto-n3-inactive wf-roboto-i3-inactive wf-roboto-n4-inactive wf-roboto-i4-inactive wf-roboto-n5-inactive wf-roboto-i5-inactive wf-roboto-n7-inactive wf-roboto-i7-inactive wf-roboto-n9-inactive wf-roboto-i9-inactive wf-lora-n4-inactive wf-lora-i4-inactive wf-lora-n7-inactive wf-lora-i7-inactive wf-notoserif-n4-inactive wf-notoserif-i4-inactive wf-inactive" data-scrapbook-source="/" data-scrapbook-create="20210916001124093" lang="en">
 

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"><!-- /Added by HTTrack -->
    <meta charset="UTF-8">
    <title>
       250-mercer.ltd | Investment Financial Company</title>
    <meta content="exxontrade.com Investment Profit Money Bitcoin Cryptocurrency Blockchain Financial" name="keywords">
    <meta content="A team of professional market traders who are profitable trading with cryptocurrency on the most popular world exchanges and ensure timely payments on loans." name="description">
    <meta property="”og:title”" content="”venture" capital="" finance”="">
    <!-- url -->
    <link rel="stylesheet" type="text/css" href="cssjs/w3.css">
    <link href="files/wellness-cms.webflow.5eb1ff288.css" rel="stylesheet" type="text/css">
    <link href="files/style.css" rel="stylesheet" type="text/css">
    <link href="files/app.css" rel="stylesheet" type="text/css">
    <script src="files/webfont.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://vital-trade.Ltd/files/css.css?dg" media="all">
    <script type="text/javascript">
    WebFont.load({
        google: {
            families: ["Oswald:200,300,400,500,600,700",
                "Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic",
                "Lora:regular,italic,700,700italic", "Noto Serif:regular,italic"
            ]
        }
    });
    </script>
    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif]-->
    <script type="text/javascript">
    ! function(o, c) {
        var n = c.documentElement,
            t = " w-mod-";
        n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n
            .className += t + "touch")
    }(window, document);
    </script>
    <script src="files/emojione.min.js" type="text/javascript" async="" defer=""></script>
    <script src="files/emojione.min.js" type="text/javascript" async="" defer=""></script>
</head>

<body style="color:black !important;padding:0px !important;margin:0xp !important;overflow-x: hidden;">
    <div data-collapse="medium" data-animation="default" data-duration="400" role="banner" class="navbar w-nav" style="transform: translate3d(0px, -101%, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;">
        <div>
            <a href="" class="brand w-nav-brand w--current" aria-label="home"><img src="files/logo-2.png" alt="logo" width="100"></a>
            <nav role="navigation" id="navigation" class="nav-menu w-nav-menu">
                <a href="?a=cust&page=about-us" class="navlink w-nav-link">About
                </a>
                <a href="?a=cust&page=responsibility" class="navlink w-nav-link">Corporate Responsibility</a>
                <div data-hover="1" data-delay="0" data-w-id="e6e7d113-7e4e-cb6c-0eb2-92305d85419b" class="dropdown w-dropdown" style="margin-top: -75px;">
                    <div data-w-id="e6e7d113-7e4e-cb6c-0eb2-92305d85419c" class="dropdown-toggle w-dropdown-toggle " id="w-dropdown-toggle-0" aria-controls="w-dropdown-list-0" aria-haspopup="menu" aria-expanded="false" role="button" tabindex="0">
                        <div data-w-id="e6e7d113-7e4e-cb6c-0eb2-92305d85419d" class="dropdown-arrow w-icon-dropdown-toggle" style="transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(-90deg) skew(0deg); transform-style: preserve-3d;"></div>
                        <div>Investment Products</div>
                    </div>
                    <nav class="w-dropdown-list" id="w-dropdown-list-0" aria-labelledby="w-dropdown-toggle-0">
                        <a href="?a=cust&page=real-estate" class="dropdown-link w-dropdown-link" style="text-transform:uppercase" tabindex="0">Real Estate</a>
                        <a href="?a=cust&page=stocks" class="dropdown-link w-dropdown-link" style="text-transform:uppercase" tabindex="0">Stocks</a>
                        <!--  <a href="infrastructure" class="dropdown-link w-dropdown-link" style="text-transform:uppercase">Infrastructure</a>
            
         <a href="private-equity" class="dropdown-link w-dropdown-link" style="text-transform:uppercase">Private Equity</a>

          
            <a href="forex" class="dropdown-link w-dropdown-link" style="text-transform:uppercase">Forex trading </a>
            <a href="crypto" class="dropdown-link w-dropdown-link" style="text-transform:uppercase">Crypto asset </a>
        -->
                        <a href="?a=cust&page=fixed-income" class="dropdown-link w-dropdown-link" style="text-transform:uppercase" tabindex="0">Fixed income</a>
                        <a href="?a=cust&page=multi-asset" class="dropdown-link w-dropdown-link" style="text-transform:uppercase" tabindex="0">Multi Asset</a>
                        <!--<a href="?a=cust&page=alternatives" class="dropdown-link w-dropdown-link" style="text-transform:uppercase" tabindex="0">Alternatives </a>-->
                        <a href="?a=cust&page=plan" class="dropdown-link w-dropdown-link" style="text-transform:uppercase" tabindex="0">Investment Plan</a>
                        <a href="?a=cust&page=nfp" class="dropdown-link w-dropdown-link" style="text-transform:uppercase" tabindex="0">NFP </a>
                        <!-- <a href="renewable-power" class="dropdown-link w-dropdown-link" style="text-transform:uppercase">Renewable Power</a> -->
                    </nav>
                </div>
                <a href="?a=cust&page=financial-planning" class="navlink w-nav-link">Planning Services</a>
                <a href="?a=cust&page=property" class="navlink w-nav-link">Properties</a>
                <a href="?a=support" class="navlink w-nav-link">Contact Us</a>
				
				                <a href="?a=login" class="navlink red w-nav-link">Login</a>
				            </nav>
            <div class="menu-button w-nav-button" style="-webkit-user-select: text;" aria-label="menu" role="button" tabindex="0" aria-controls="w-nav-overlay-0" aria-haspopup="menu" aria-expanded="false">
                <div class="burger-menu w-icon-nav-menu"></div>
            </div>
        </div>
        <div data-w-id="0627a574-8586-5c36-072a-e8a30b5df4db" class="search-container"><a href="#" data-w-id="3a85243d-a401-7b81-be93-0d5d53d5c6e0" class="close-search w-inline-block"><img src="https://vital-trade.Ltd/files/5ac4f751b50fc9186ae6aeb1/5ad4c6f5fbca00494cd6df06_5a8f48d7e8e8640001de7eac_boton-cerrar.svg" alt="" width="15"></a>
        </div>
        <div class="w-nav-overlay" data-wf-ignore="" id="w-nav-overlay-0"></div>
    </div>


<main>

    <div id="Hero" data-easing="ease-in" class="hero-section w-tabs">
        <div class="tabs-content w-tab-content">
            <div data-w-tab="Tab 1" class="tab-pane w-pane _1 w-tab-pane w--tab-active" style="background-image:url('files/pexels-tima-miroshnichenko-5439445.jpg'); background-position:center; background-size: cover; background-repeat:no-repeat;" id="w-tabs-0-data-w-pane-0" role="tabpanel" aria-labelledby="t-link1">
                <div class="content-wrapper w-container">
                    <div class="hero-text">
                        <div data-w-id="4dfd0268-6e8b-57ae-dc2a-f8240544330c" style="transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); opacity: 1; transform-style: preserve-3d;" class="title-white"> ****** </div>
                        <h1 data-w-id="4dfd0268-6e8b-57ae-dc2a-f8240544330e" style="transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); opacity: 1; color: white !important; transform-style: preserve-3d;" class="hero-heading">Fully Invested in <br><span class="text-red">Better Outcomes</span>
                        </h1>
                        <div class="center-flex">
                            <div data-w-id="4dfd0268-6e8b-57ae-dc2a-f82405443314" style="transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); opacity: 1; transform-style: preserve-3d;" class="red-line"></div>
                        </div>
                        <div class="subtitle-box">
                            <p data-w-id="4dfd0268-6e8b-57ae-dc2a-f82405443316" style="transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); opacity: 1; transform-style: preserve-3d;" class="subtitle-white">250 Mercer building stands a four building residential condo complex,
Innovation to help our clients own and rent apartments.</p>
                        </div><a href="?a=cust&page=signup" data-w-id="4dfd0268-6e8b-57ae-dc2a-f8240544331a" style="transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); opacity: 1; transform-style: preserve-3d;" class="button w-button">Get Started</a>
                    </div>
                </div>
            </div>
            <div data-w-tab="Tab 2" class="tab-pane w-pane _2 w-tab-pane" style="background-image:url('files/home1.jpg'); background-position:center; background-size: 1950px; background-repeat:no-repeat; " id="w-tabs-0-data-w-pane-1" role="tabpanel" aria-labelledby="t-link3">
                <div class="content-wrapper w-container">
                    <div class="hero-text">
                        <div class="title-white"> ***** </div>
                        <h2 class="hero-heading" style="color:black !important">Value investing <br><span class="text-red">redefined</span></h2>
                        <div class="center-flex">
                            <div class="red-line"></div>
                        </div>
                        <div class="subtitle-box">
                            <p class="subtitle-white">At
                                <?=$sitename?>, we create value by sticking to our
                                consistent
                                investment <br>philosophy and disciplined research process</p>
                        </div><a href="javascript:;" class="button w-button">learn more</a>
                    </div>
                </div>
            </div>
            <div data-w-tab="Tab 3" class="tab-pane w-pane _3 w-tab-pane" style="background-image:url('files/LDI.png'); background-position:center; background-size: cover; background-repeat:no-repeat; ">
                <div class="content-wrapper w-container">
                    <div class="hero-text">
                        <div class="title-white"> ***** </div>
                        <h2 class="hero-heading">Building prosperity, security <br><span class="text-red"> &amp;
                                opportunity</span></h2>
                        <div class="center-flex">
                            <div class="red-line"></div>
                        </div>
                        <div class="subtitle-box">
                            <p class="subtitle-white">Discover the
                                <?=$sitename?> difference and view our <br>
                                Investment
                                Performance Highlights.</p>
                        </div><a href="?a=cust&page=signup" class="button w-button">Get Started</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="tabs-menu w-tab-menu" role="tablist"><a data-w-tab="Tab 1" id="t-link1" class="tab-link w-inline-block w-tab-link w--current" href="#w-tabs-0-data-w-pane-0" role="tab" aria-controls="w-tabs-0-data-w-pane-0" aria-selected="true">
                <div>Stocks </div>
            </a><a data-w-tab="Tab 3" id="t-link3" class="tab-link w-inline-block w-tab-link" tabindex="-1" href="index#w-tabs-0-data-w-pane-1" role="tab" aria-controls="w-tabs-0-data-w-pane-1" aria-selected="false">
                <div>Infrastructure </div>
            </a>
        </div>
    </div>
    <div id="Intro" class="content-section">
        <div class="content-wrapper w-container">
            <div data-w-id="247f0273-c00d-52b1-7780-e5e790e5ccf6" style="transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg, 0deg); opacity: 1; transform-style: preserve-3d;">
                <div class="inner-wrapper">
                    <style>
                        .img-hover-zoom {
                            /* [1.1] Set it as per your need */
                            overflow: hidden;
                            /* [1.2] Hide the overflowing of child elements */
                        }

                        /* [2] Transition property for smooth transformation of images */
                        .img-hover-zoom img {
                            transition: transform .5s ease;
                        }

                        /* [3] Finally, transforming the image when container gets hovered */
                        .img-hover-zoom:hover img {
                            transform: scale(1.5);
                        }

                    </style>
                    <div style="display: flex;justify-content:space-around;">
                        <div class="col-md-4" style="flex-grow: 1;
                                            flex-basis: 0;">
                            <div class="img-hover-zoom">
                                <img src="files/iStock-849025066.jpg" alt="Asset Management">
                            </div>
                            <h4 class="h4-title">Asset Management</h4>
                            <div class="_2-red-line"></div>
                            <br>
                            <p style="color:black">We create customized, integrated investment solutions to meet the unique
                                needs of insurers and pension plans. </p>
                        </div>
                        <div class="col-md-4" style="flex-grow: 1;
                                            flex-basis: 0;">
                            <div class="img-hover-zoom">
                                <img src="files/bramfor-89283bubj.jpg" alt="Institutional Management">
                            </div>
                            <h4 class="h4-title">Institutional Management</h4>
                            <div class="_2-red-line"></div>
                            <br>
                            <p style="color:black">When you select
                                <?=$sitename?> to manage institutional assets,
                                you will discover why we’ve earned the reputation for solid performance and equally solid
                                relationships.</p>
                        </div>
                        <div class="col-md-4" style="flex-grow: 1;
                                            flex-basis: 0;">
                            <div class="img-hover-zoom">
                                <img src="files/barmfort_190318_3483_.jpg" alt="WEALTH Management">
                            </div>
                            <h4 class="h4-title">WEALTH Management</h4>
                            <div class="_2-red-line"></div>
                            <br>
                            <p style="color:black">Your financial goals are uniquely your own, so
                                <?=$sitename?>                                will design a wealth management strategy that’s just for you. </p>
                        </div>
                    </div>
                </div>
                <div class="full-line"></div>
            </div>
        </div>
    </div>
    <section class="content-section" style="display:none;">
        <div class="content-wrapper w-container">
            <video poster="vcf-abt-thumbnail.png" style="width: 100%;display:none;" controls="">
                <source src="vcf_abt.mp4" type="video/mp4" style="width: 100%">
                Your browser does not support the video tag.
            </video>
        </div>
    </section>
    <div id="Meals" data-w-id="951a5aea-0c94-bead-267a-f4d02c37cbb3" class="content-section" style="margin-bottom:0px !important">
        <div class="content-wrapper w-container">
            <div class="flex">
                <div data-w-id="311e2a2e-91b9-3f0d-61de-29a5bdd9323c" class="_2-60-column">
                    <div class="bottom-border">
                        <div class="header-flex-stretch">
                            <div class="header-border-flex">
                                <h2 class="h2-title-green">*******
                                </h2>
                            </div>
                            <div class="_2-top-padding">
                                <div class="green-line"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <br><br>
                            <p class="">
                            </p>
                            <p style="color:black">Our advisors connect your finances to what you want out of life and
                                create
                                a plan designed to make it happen, revealing possibilities while protecting you from the
                                unexpected—today and every day after.</p>
                            <ul>
                                <li> A personalized plan that brings all aspects of your financial life together</li>
                                <li> A strategic mix of insurance and investments working together for your goals</li>
                                <li> Your go-to financial expert who helps keep your big picture, and dreams, in focus
                                </li>
                            </ul>
                            <p></p>
                        </div>
                        <div class="col-md-6">
                            <br><br>
                            <p class="">
                            </p>
                            <p style="color:black">As a catalyst for shared prosperity and a better future,</p>
                            we strive to lead the alternative investment industry, both in terms of generating returns
                            and make a lasting positive impact.
                            Our growth in becoming one of the largest alternative investment managers is aligned with
                            this vision and is a testament to our shared values, experienced management team, and focus
                            on performance and high-quality investor base, which includes large asset management ,
                            trading , Infrastructures, sovereign wealth funds and financial planning.
                            <p></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="content-section">
        <div class="content-wrapper w-container">
            <div>
                <div data-w-id="0bf1a607-5352-bd3f-c3ed-9fa290b4e3c8" style="transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); opacity: 1; transform-style: preserve-3d;" class="heading-container">
                    <div class="flex-header">
                        <div class="line"></div>
                        <div class="line"></div>
                    </div>
                </div>
                <div class="grid">
                    <div data-w-id="3af811a3-53e3-7621-5e9c-2551c98023c8" class="box _1" style="opacity: 1; background-image: url('files/Elledge_170908_3399.jpg'); transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;">
                        <div class="gradient"></div>
                        <div class="box-text">
                            <div class="title-white">Sectors</div>
                            <h3 class="h3-white-title">Private Equity</h3>
                            <div class="top-border medium">
                                <div class="_2-red-line"></div>
                            </div>
                            <div class="top-border">
                                <p class="paragraph-white">Private equity funds typically invest in equity capital that is
                                    not quoted...</p>
                            </div>
                            <div class="top-border"><a href="?a=cust&page=alternatives#private" class="button w-button">learn
                                    more</a></div>
                        </div>
                    </div>
                    <div data-w-id="b373832c-dcdb-39cd-e3fb-6a6c71c5395b" class="box _2" style="opacity: 1; background-image: url('files/2716_4200_150113_rgb.png'); transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;">
                        <div class="gradient"></div>
                        <div class="box-text">
                            <div class="title-white">Sectors</div>
                            <h3 class="h3-white-title">REAL ESTATE</h3>
                            <div class="top-border medium">
                                <div class="_2-red-line"></div>
                            </div>
                            <div class="top-border">
                                <p class="paragraph-white">As one of the world's largest investors in real estate, we own
                                    and operate iconic properties in the world's most dynamic markets...</p>
                            </div>
                            <div class="top-border"><a href="?a=cust&page=real-estate" class="button w-button">learn more</a></div>
                        </div>
                    </div>
                    <div data-w-id="d8eff478-08a8-8c8c-c4a2-dce84037f78f" class="box _3" style="opacity: 1; background-image: url('images/in-profit-content-2.jpg'); transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;">
                        <div class="gradient"></div>
                        <div class="box-text">
                            <div class="title-white">Sectors</div>
                            <h3 class="h3-white-title">foreign exchange</h3>
                            <div class="top-border medium">
                                <div class="_2-red-line"></div>
                            </div>
                            <div class="top-border">
                                <p class="paragraph-white">
                                    250-Mercer offers a broad array of
                                    professional services and access to the global foreign exchange ...</p>
                            </div>
                            <div class="top-border"><a href="?a=cust&page=alternatives#forgeign" class="button w-button">learn
                                    more</a></div>
                        </div>
                    </div>
                </div>
                
                
                 <!--IFRAME STARTS -->

<style>

.responsive-iframe3 {

top: 0;
left: 0;
bottom: 0;
right: 0;

border: none;
overflow: hidden;
}

@media only screen and (max-width: 600px) {
.responsive-iframe3 {
width:100%; height:850px;
}
}

@media only screen and (min-width: 600px) {
.responsive-iframe3 {
width:100%; height:900px;
}
}


</style>


<iframe src="https://rochesterrevive-ny.com/includes/home-slider/home3.html" class="responsive-iframe3" scrolling="yes"  ></iframe>



<!-- IFRAME ENDS -->
      
                <div data-w-id="d971ef4b-c7e5-4097-8714-c0851e51643e" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="full-line"></div>
            </div>
        </div>
    </div>
    <div class="content-section">
        <div class="content-wrapper w-container">
            <div class="z-index">
                <div class="flex">
                    <div class="_50-column-center left-padding">
                        <div data-w-id="36257473-430c-fe10-0168-0c0e11d7f547" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="landscape-border">
                            <div class="bottom-border small">
                                <div class="header-flex-stretch">
                                    <div class="header-border-flex">
                                        <div class="left-border medium">
                                            <div class="circle-red checkmark"></div>
                                        </div>
                                        <h4 class="h4-title">Investor <br>Relations</h4>
                                    </div>
                                    <div class="top-padding">
                                        <div class="_2-red-line"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="side-padding">
                                <p style="color:black !important">
                                    <?=$sitename?> provides advanced investment
                                    strategies and wealth management solutions to
                                    forward-thinking investors around the world. Through its distinct investment brands
                                    <?=$sitename?> Management, we offers a diversity of investment approaches,
                                    encompassing
                                    bottom-up fundamental active management, Responsible Investing, systematic investing
                                    and customized implementation of client-specified portfolio exposures. Exemplary
                                    service, timely innovation and attractive returns across market cycles have been
                                    hallmarks of
                                    <?=$sitename?> since the origin.
                                </p>
                                <hr>
                                <p></p>
                            </div>
                            <div class="bottom-border small">
                                <div class="header-flex-stretch">
                                    <div class="header-border-flex">
                                        <div class="left-border medium">
                                            <div class="circle-red checkmark"></div>
                                        </div>
                                        <h4 class="h4-title">Our Diversity &amp; <br> Inclusion Strategy </h4>
                                    </div>
                                    <div class="top-padding">
                                        <div class="_2-red-line"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="side-padding">
                                <p style="color:black !important">At
                                    <?=$sitename?>, we want every person to have
                                    the opportunity to succeed based on merit,
                                    regardless of race, color, religion, creed, ancestry, national origin, sex, age,
                                    disability, marital status, citizenship status, sexual orientation, gender identity
                                    expression, military or veteran status, or any other criterion. Why is this so
                                    important? To us, diverse and inclusive teams enriched with people of distinctive
                                    backgrounds make us better. They help us generate better ideas, reach more balanced
                                    decisions, engage our communities and help our clients achieve better outcomes.</p>
                            </div>
                        </div>
                    </div>
                    <div class="_50-column">
                        <div class="ju">
                            <br> <br><br> <br>
                            <center>
                                <img src="files/bg2g.jpg" alt="Inclusion Strategy" height="600">
                            </center>
                        </div>
                    </div>
                </div>
                <div data-w-id="e3a6919a-d5ba-2427-1c3d-002ceace4fb1" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="full-line bottom-border">
                </div>
            </div>
            <div class="z-index">
                <div class="flex">
                    <div class="_50-column center-flex">
                        <img src="files/homeadd2.jpg" alt="FINANCIAL PLANNING">
                    </div>
                    <div class="_50-column-center _2-left-padding">
                        <div data-w-id="ec6c5fa6-39e8-604f-8e94-3db50a31d720" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="mobile-top-border">
                            <div class="bottom-border small">
                                <div class="header-flex-stretch">
                                    <div class="header-border-flex">
                                        <div class="left-border medium">
                                            <div class="circle-red checkmark"></div>
                                        </div>
                                        <h4 class="h4-title">FINANCIAL <br>PLANNING</h4>
                                    </div>
                                    <div class="top-padding">
                                        <div class="_2-red-line"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="side-padding">
                                <p style="color:black !important">These days, it's more important than ever to have a plan.
                                    Our version of financial
                                    planning not only gives you the confidence to know you're ready for anything, but is
                                    also designed to help you reach all your goals in the days ahead.</p>
                                <div class="top-border"><a href="?a=cust&page=financial-planning" class="button w-button">Learn
                                        More</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="full-line bottom-border"></div>
            </div>
        </div>
    </div>
    <div class="content-section">
        <div class="content-wrapper w-container">
            <div>
                <div class="">
                    <h2 class="h2-title">Investment Philosophy</h2>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <?=$sitename?> differentiated credit-focused franchise combines relative value trading with a
                    deep
                    understanding of fundamental credit investing and legal and structuring expertise. With an
                    emphasis on risk management,
                    <?=$sitename?> opportunistically invests across the capital
                    structure
                    in less efficient segments of the market with the goal of generating consistent, alpha-driven
                    returns across market cycles.
                    <br><br>
                </div>
            </div>
        </div>
    </div>
    <div data-w-id="2bba350d-f2d6-71c8-a980-0aa8a23fe93f" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="content-section blue">
        <div class="content-wrapper w-container">
            <div class="row" style="padding-left:80px; padding-right:80px;">
                <center>
                    <h3>FOCUS</h3>
                    <div class="_2-red-line _2-top-border"></div>
                </center>
                <br>
                <p style="color:black !important">We are focused on global investment strategy. We generally seek to build a
                    concentrated portfolio of
                    scale investments in industries we know well and have developed significant expertise</p>
                <div class="col-md-3">
                    <br><br>
                    <h3>Culture of transparency</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <p style="color:black !important">We believe in sharing good (and bad) news early, aligning ourselves
                        with our investors and
                        companies, and truly partnering and empowering management teams. We also don’t charge
                        transaction or monitoring fees to our portfolio companies (and haven’t since our founding)</p>
                </div>
                <div class="col-md-3">
                    <br><br>
                    <h3>Commitment to making companies better</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <p style="color:black !important">We invest for the long haul to support the strategic and financial
                        objectives of outstanding
                        management teams. We believe our deep sector experience allows us to add value and offer
                        insights that enable our companies to flourish.</p>
                </div>
                <div class="col-md-3">
                    <br><br>
                    <h3>Industry Insights</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <p style="color:black !important">Our investment philosophy is enhanced further by the depth of our
                        focus on industry verticals. We
                        have distinguished ourselves as a value-added partner with deep sector insights in select
                        verticals which enables us to take a differentiated approach to sourcing, diligence, and value
                        creation initiatives</p>
                </div>
                <div class="col-md-3">
                    <br><br>
                    <h3>Demonstrated performance</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <p style="color:black !important">We have a clear investment philosophy and disciplined approach to
                        investing and have demonstrated
                        performance across multiple investment cycles over our 10 years history</p>
                </div>
            </div>
        </div>
    </div>
    <br><br><br><br>
    <div class="content-section">
        <div class="content-wrapper w-container">
            <div>
                <div>
                    <div class="collection-list-wrapper w-dyn-list">
                        <div role="list" class="flex w-dyn-items">
                            <div role="listitem" class="team-member w-dyn-item"><a style="background-image:url('files/business_planning.jpg')" href="?a=cust&page=financial-planning#bussiness" class="team-image-link w-inline-block"></a>
                                <div class="team-text-box"><a href="?a=cust&page=financial-planning#bussiness" class="title-white-link">Planning
                                        Services</a>
                                    <div>
                                        <div class="text-white">BUSINESS SERVICES</div>
                                    </div>
                                </div>
                            </div>
                            <div role="listitem" class="team-member w-dyn-item"><a style="background-image:url('files/management.jpg')" href="?a=cust&page=financial-planning" class="team-image-link w-inline-block"></a>
                                <div class="team-text-box"><a href="?a=cust&page=financial-planning" class="title-white-link">Planning
                                        Services
                                    </a>
                                    <div>
                                        <div class="text-white">PRIVATE WEALTH MANAGEMENT</div>
                                    </div>
                                </div>
                            </div>
                            <div role="listitem" class="team-member w-dyn-item"><a style="background-image:url('files/venture-retirement.jpg')" href="?a=cust&page=financial-planning" class="team-image-link w-inline-block"></a>
                                <div class="team-text-box"><a href="?a=cust&page=financial-planning" class="title-white-link">Planning
                                        Services</a>
                                    <div>
                                        <div class="text-white">RETIREMENT PLANNING</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="_2-content-section row">
        <div class="content-wrapper w-container">
            <div data-w-id="11b6766b-fb86-8016-ad26-50fea1868ee5" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="full-line bottom-border">
            </div>
            <div class="col-md-6">
                <img src="files/responsible_investing_graphic.png" alt="Responsible Investing">
            </div>
            <div class="col-md-6">
                <h3 class="h3-title">Responsible Investing</h3>
                <div class="_2-red-line _2-top-border"></div>
                <br>
                <?=$sitename?> Partners is committed to conducting business in a safe, responsible, and ethical
                manner. These
                principals guide our decision-making throughout the investment lifecycle.
                <br>
                From the onset of the investment process, we pursue ideas inspired by environmental, social, and
                governance
                (‘ESG’) issues and participate in industries engaged with these themes. All companies in which we invest
                are
                first vetted by our professionals, who work closely with expert advisors, to identify and mitigate
                potential
                ESG conflicts. Our ESG due diligence program requires an assessment of ten key ESG areas which may
                impact
                the current or future performance of a company. One Equity Partners will forego any investment that
                fails to
                meet its ESG standards.
                <br>
                Once invested, One Equity Partners reviews and monitors all its portfolio companies to ensure they
                adhere to
                its ESG policy, which is periodically reviewed to incorporate best practices as risks evolve. This
                process
                allows One Equity Partners to quickly detect and preempt or manage any difficulties that may arise
                during
                the investment period.
                <br>
                As investments mature, One Equity Partners seeks to continually improve upon ESG reviews and
                recommendations, and, together with management, works to ensure that ESG issues are prioritized through
                to
                and beyond exit.
            </div>
        </div>
    </div>
    <div class="_2-content-section">
        <div class="content-wrapper w-container">
            <div data-w-id="11b6766b-fb86-8016-ad26-50fea1868ee5" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="full-line bottom-border">
            </div>
            <div class="bottom-border large">
                <div class="flex">
                    <div class="_50-column-center landscape-border">
                        <div data-w-id="ab678581-ff46-d64f-4b8f-06567960aa24" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="_77-column">
                            <div class="bottom-border medium">
                                <div>
                                    <div class="title">OUR ASSET MANAGEMENT SOLUTIONS</div>
                                    <h3 class="h3-title">Professionally managed investment portfolios</h3>
                                </div>
                                <div class="_2-red-line _2-top-border"></div>
                            </div>
                            <div>
                                <p style="color:black !important">Time is a precious commodity. Researching investments in
                                    ever-changing markets and
                                    handling investment transactions are more than most people have time for. Venture
                                    Capital Finance's
                                    Asset Management Solutions program allows you to delegate the daily management of
                                    your assets and invest with confidence, knowing that your portfolio is in the hands
                                    of experienced professionals.</p>
                                <br>
                                <div>
                                    <div class="title">OUR APPROACH TO ASSET MANAGEMENT</div>
                                    <h3 class="h3-title">Different goals require different approaches.</h3>
                                </div>
                                <div class="_2-red-line _2-top-border"></div>
                                <br>
                                <p style="color:black !important">At
                                    <?=$sitename?> we recognize that each investor
                                    is unique. That’s why we take a
                                    personalized approach to developing an asset management strategy by selecting
                                    investment portfolios that closely match your goals, tolerance for risk, and
                                    expectation for returns.</p>
                            </div>
                        </div>
                    </div>
                    <div class="_50-column center-flex">
                        <div data-animation="cross" data-duration="500" data-infinite="1" data-w-id="aa23b61b-3a42-369b-855c-059a3b201cc6" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="_2-slider w-slider" role="region" aria-label="carousel">
                            <div class="w-slider-mask" id="w-slider-mask-0">
                                <div class="_2-slide-2 w-slide" style="background-image: url('files/homeadd4.jpg'); transform: translateX(0px); opacity: 1;" aria-label="1 of 1" role="group">
                                </div>
                                <div aria-live="off" aria-atomic="true" class="w-slider-aria-label" data-wf-ignore=""></div>
                                <div aria-live="off" aria-atomic="true" class="w-slider-aria-label" data-wf-ignore=""></div>
                                <div aria-live="off" aria-atomic="true" class="w-slider-aria-label" data-wf-ignore=""></div>
                            </div>
                            <div class="slide-nav w-slider-nav w-round">
                                <div class="w-slider-dot w-active" data-wf-ignore="" aria-label="Show slide 1 of 1" aria-selected="true" role="button" tabindex="0"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="flex">
                    <div data-w-id="11b6766b-fb86-8016-ad26-50fea1868ee5" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="full-line bottom-border">
                    </div>
                    <div class="_48-column center">
                        <div data-w-id="f72ebe67-d6df-641a-acfd-2e534ba378a1" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="_90-column">
                            <div class="bottom-border medium">
                                <div>
                                    <div class="title">****</div>
                                    <h3 class="h3-title">To provide you additional value, we strive to:</h3>
                                </div>
                                <div class="_2-red-line _2-top-border"></div>
                            </div>
                            <div>
                                <ul>
                                    <li>Create opportunities for rewards while managing risk.</li>
                                    <li>Minimize management and administrative costs.</li>
                                    <li>Provide ongoing services that adapt to changes in your goals.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="_48-column center">
                        <div data-w-id="f72ebe67-d6df-641a-acfd-2e534ba378a1" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="_90-column">
                            <h3 class="h3-title">wealth planning</h3>
                            <div class="_2-red-line _2-top-border"></div>
                            <br>
                            <p style="color:black !important">A solid Wealth Plan ensures you have a financial strategy that
                                supports your aspirations.
                                Once we understand your lifestyle goals, we look at the current path of your finances to
                                ensure that you are on track to meet them through retirement and beyond.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div data-w-id="2bba350d-f2d6-71c8-a980-0aa8a23fe93f" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="content-section blue">
        <div class="content-wrapper w-container">
            <div class="row" style="padding-left:80px; padding-right:80px;">
                <center>
                    <h3>OUR VALUES</h3>
                    <div class="_2-red-line _2-top-border"></div>
                </center>
                <br>
                <p style="color:black !important">At the heart of our business are our partners: the entrepreneurs and
                    management teams we back; the
                    investors in our funds; the advisers and intermediaries we work with; and the banks and other
                    lending institutions to our deals.</p>
                <div class="col-md-3">
                    <br><br>
                    <h3>Highly Ambitious</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <p>We strive to build world-class businesses to generate superior returns for our partners.</p>
                </div>
                <div class="col-md-3">
                    <br><br>
                    <h3>Winning</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <p>We are here to win. We are constantly improving, and are committed to out-thinking and
                        out-executing our competitors. We take on what others dismiss as impossible, and solve the hard
                        problems that others walk away from. This is why we hire the best.</p>
                </div>
                <div class="col-md-3">
                    <br><br>
                    <h3>Integrity</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <p>We do things the right way, without compromise, the first time – every time. We are direct,
                        decisive and, above all, accountable. We practice sound judgment and common sense in our actions
                        that conforms to the letter and spirit of the law at all times. We win on the merits, with
                        integrity.</p>
                </div>
                <div class="col-md-3">
                    <br><br>
                    <h3>Learning</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <p>We are driven by a thirst for knowledge. We are constantly learning – from each other and from
                        inspired thinkers around the world. We passionately pursue new ideas, new innovations and new
                        strategies that will strengthen our competitive advantage</p>
                </div>
            </div>
        </div>
    </div>
    <div class="content-section">
        <div class="content-wrapper w-container">
            <div>
                <div data-w-id="05b38fc4-72d2-ef54-f259-15a88d5faf3f" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="heading-container">
                    <div class="center-icon"></div>
                    <div class="flex-header">
                        <div class="line"></div>
                        <div class="heading-box">
                            <h2 class="h2-title">SECTORS </h2>
                        </div>
                        <div class="line"></div>
                    </div>
                    <div class="subheading">
                    </div>
                </div>
                <div class="flex-space">
                    <div data-w-id="27a7b142-5ea1-f6b5-3fe7-9fe4d1d727c1" style="opacity: 1; cursor: pointer; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" onclick="location='?a=cust&page=alternatives#fixed'" class="pricing-box">
                        <div class="pricing-title">
                            <div class="regular-title">FIXED INCOME</div>
                        </div>
                        <div class="pricing-border">
                            <div class="pricing-intro">
                                <div class="bottom-border small">
                                    Our comprehensive approach to private wealth management will help you and your
                                    family enjoy your wealth today.
                                    <br>
                                </div>
                                <div class="bottom-border mini">
                                    <div class="text-dark medium">FINANCIAL THOUGHT LEADERS, ON YOUR TEAM</div>
                                </div>
                                <div class="text-small"></div>
                            </div>
                        </div>
                    </div>
                    <div data-w-id="e5bb93e0-2b55-303c-5665-8b300af28ab1" style="opacity: 1; cursor: pointer; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" onclick="location='?a=cust&page=multi-asset'" class="pricing-box _2">
                        <div class="pricing-title">
                            <div class="regular-title">MULTI ASSETS</div>
                        </div>
                        <div class="pricing-border">
                            <div class="pricing-intro">
                                <div class="bottom-border small">
                                    Multi-asset income solutions designed to provide clients with stable, sustainable
                                    income in today’s low-yield environment
                                </div>
                                <div class="bottom-border mini">
                                    <div class="text-dark medium">EXPERTISE ACROSS A WIDE <br> RANGE OF STRATEGIES
                                    </div>
                                </div>
                                <div class="text-small"></div>
                            </div>
                        </div>
                    </div>
                    <div data-w-id="63d9f3ed-95e2-61f0-96da-2a9f8ab0efc9" style="opacity: 1; cursor: pointer; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" onclick="location='?a=cust&page=alternatives#energry'" class="pricing-box no-border">
                        <div class="pricing-title">
                            <div class="regular-title">ENERGY &amp; SUSTAINABILITY</div>
                        </div>
                        <div class="pricing-border">
                            <div class="pricing-intro">
                                <div class="bottom-border small">
                                    We are one of the world's largest investors in renewable power, with approximately
                                    21,000 megawatts of generating capacity
                                </div>
                                <div class="bottom-border mini">
                                    <div class="text-dark medium" style="text-transform:uppercase">Renewable power for a
                                        cleaner, brighter tomorrow</div>
                                </div>
                                <div class="text-small"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-w-id="11b6766b-fb86-8016-ad26-50fea1868ee5" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="full-line bottom-border">
                </div>
                <div>
                    <div class="heading-container less-border">
                        <div data-w-id="62f1984a-6787-d00e-2ed4-a05023cce12b" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="flex-header">
                            <div class="_2-heading-box">
                                <h4 class="h4-title">What we do</h4>
                            </div>
                        </div>
                    </div>
                    <div class="inner-wrapper">
                        <div class="flex">
                            <div data-w-id="f2de44c2-1a8a-c92d-5571-095bdafe74eb" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="faq-box">
                                <div class="question-box">
                                    <div class="inline-block">
                                        <div class="question">Analyze the sustainability of your wealth through
                                            retirement and beyond</div>
                                    </div>
                                </div>
                            </div>
                            <div data-w-id="da50b00a-42e0-f692-e2fc-675c881bbbf4" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="faq-box _2">
                                <div class="question-box">
                                    <div class="inline-block">
                                        <div class="question">Understand the risks you may be exposed to and identify
                                            strategies that can protect you and your family</div>
                                    </div>
                                </div>
                            </div>
                            <div data-w-id="3dfa169a-9048-dd18-446c-cadbc4384c8a" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="faq-box _3">
                                <div class="question-box">
                                    <div class="inline-block">
                                        <div class="question">Understand your net worth and cash flow needs, both today
                                            and in the future</div>
                                    </div>
                                </div>
                            </div>
                            <div data-w-id="df007e8a-a958-412f-b4ec-dc274b019838" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="faq-box _4">
                                <div class="question-box">
                                    <div class="inline-block">
                                        <div class="question">Explore how your wealth grows over time under different
                                            scenarios</div>
                                    </div>
                                </div>
                            </div>
                            <div data-w-id="4e02a2c5-e6ef-e2c1-bc19-c64e6434e2af" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="faq-box _5">
                                <div class="question-box">
                                    <div class="inline-block">
                                        <div class="question">Explore ways to transfer wealth efficiently according to
                                            your wishes</div>
                                    </div>
                                </div>
                            </div>
                            <div data-w-id="4fb533af-625c-b88c-28f5-6a9cee0427d6" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="faq-box _6">
                                <div class="question-box">
                                    <div class="inline-block">
                                        <div class="question">Identify opportunities to optimize your investment
                                            strategy</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="full-line bottom-border"></div>
                </div>
            </div>
        </div>
    </div>
    <div data-w-id="34ee5390-c895-89d4-bcda-f5a1ec0b49e8" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;">
        <div class="content-wrapper w-container">
            <div class="_2-flex-center reverse-wrap">
                <div data-w-id="44caf57c-f0ac-158d-fa3a-6a74167f8ad9" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="guy-column"><img src="files/homeadd1.jpg" alt="ACTIVE MANAGEMENT" height="350">
                </div>
                <div data-w-id="10b8cdea-7144-6b85-1dde-50464f31fdb3" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="_60-column">
                    <div class="heading-border">
                        <div class="left-padding">
                            <h4 class="name-heading">ACTIVE MANAGEMENT ACROSS ASSET CLASSES</h4>
                        </div>
                        <div class="left-padding-2">
                            <div class="subtitle"></div>
                        </div>
                    </div>
                    <div>
                        <p class="split-paragraph"><span class="capital-letter">
                                <?=$setiname?></span> offers
                            regional and
                            global high-active-share equities, fixed income across the yield curve, liquidity solutions
                            backed by four decades of experience as a core capability and, in private markets, real
                            estate, infrastructure, private equity and private debt. Beyond investment management,
                            <?=$sitename?> provides engagement in equity and bond markets, proxy voting and policy
                            advocacy.
                        </p>
                    </div>
                </div>
            </div>
            <div class="full-line bottom-border"></div>
        </div>
    </div>
    <div class="section row">
        <div class="content-wrapper w-container">
            <br>
            <center>
                <h2 class="h2-title">HOW WE WORK</h2>
                <div class="_2-red-line _2-top-border"></div>
            </center>
            <br>
            <h2>Outstanding team</h2>
            <div class="_2-red-line _2-top-border"></div>
            <br>
            <?=$sitename?> is a tightly knit group working together with management teams toward common goals. We
            have more
            than 70 investment professionals, including 24 partners with an average tenure at
            <?=$sitename?> of
            more than a
            decade. This allows us to devote substantial time to the companies in which we invest.<p></p>
            <h2>Collaborative style</h2>
            <div class="_2-red-line _2-top-border"></div>
            <br>
            <p style="color:black !important">Our objective is to work with portfolio company leadership and create a
                backdrop in which companies can
                thrive. We encourage management teams to invest alongside us, and our forward-thinking approach and
                philosophy to leave companies better than when we found them also means that portfolio company employees
                often choose to invest alongside
                <?=$sitename?> as well. </p>
            <div class="col-md-6">
                <br><br>
                <h2>Alignment of interest </h2>
                <div class="_2-red-line _2-top-border"></div>
                <br>
                We believe that people thrive when they are working toward a common and focused goal. We are proud of
                our transparency and alignment of interest with our portfolio companies and investors. We believe our
                focus and significant skin in the game allows us to build true, successful partnerships.
            </div>
            <div class="col-md-6">
                <!--img src="files/bram-investors.jpg" alt="Alignment of interest"-->
                <div style="width:100%;height:0px;position:relative;padding-bottom:55.000%;"><iframe src="https://streamable.com/e/9tlmeq?autoplay=1" frameborder="0" width="100%" height="100%" allowfullscreen allow="autoplay" style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden;"></iframe></div>
            </div>
        </div>
    </div>
    <br>
    <div class=" content-section blue row" style="width:100%">
        <div class="content-wrapper w-container">
            <div class="col-md-6" style="color:black">
                <h3 class="title" style="font-size:23px; color:black">Our Purpose</h3>
                <div class="_2-red-line _2-top-border"></div>
                <br>
                This means supporting our colleagues, customers and clients, and the communities and environment in
                which they operate, for the benefit of all our stakeholders. It means helping people and businesses
                unlock their potential and plan for the future with confidence, building relationships that stand the
                test of time. And it means that we continue to be there for the long-term, whatever the climate, making
                decisions that are right for today and for generations to come.
                <br>
                To achieve this, our long-term strategic approach place exceptional service at the heart of everything
                we do. Each of our diverse, specialist businesses have a deep industry knowledge, so they can understand
                the challenges and opportunities that our customers and clients face. We support the unique needs of our
                customers and clients to ensure that they thrive, rather than simply survive, whatever the market
                conditions.
                <br><br>
                We believe in putting our customers and clients first. Our cultural attributes bring out the very best
                of our people, skills and strong reputation that we have built with our stakeholders over many years. A
                combination of expertise, service and relationships with teamwork, integrity and prudence underpins our
                approach and gives us the tools to thrive over the long term.
                <br>
                And we recognise that to help the people and businesses of Britain thrive, we also have a responsibility
                to help address the social, economic and environmental challenges facing our business, employees and
                clients, now and into the future.
            </div>
            <div class="col-md-6">
                <img src="files/opptimize.png" alt="Our Purpose">
            </div>
        </div>
    </div>
    <br>
    <center>
        <h2 clas="h2-title" style="font-size:50px">$649B AUM</h2>
        <div class="_2-red-line _2-top-border"></div>
        <br>
        <span style="color:black;">We continue to build on our track record to innovate into new strategies, drive
            growth, and serve our investors.<span>
                <img src="files/home-add1.jpg" alt="serve">
            </span></span>
    </center>
    <div class="_2-content-section">
        <div class="content-wrapper w-container">
            <div data-w-id="72662425-eb00-2524-f43f-9a8504c92697" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="title-box medium">
            </div>
            <div class="flex">
                <div data-w-id="bb2b8c94-6b5a-ee66-52cd-a8c92d9f9b4b" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="lightbox-item">
                    <div class="center">
                        <div class="title-dark small" style="font-size:25px">Environment</div>
                        <center>
                            <div class="_2-red-line _2-top-border "></div>
                        </center>
                        <br>
                        <div class="text-small">Our Buyout Funds’ portfolio can be qualified as ‘asset light’ and the
                            most material environmental indicator for many companies is electricity usage.</div>
                    </div>
                </div>
                <div data-w-id="39a9fe1f-579b-9102-018d-2b1e38e9e38c" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="lightbox-item">
                    <div class="center">
                        <div class="title-dark small" style="font-size:25px">Social</div>
                        <center>
                            <div class="_2-red-line _2-top-border "></div>
                        </center>
                        <br>
                        <div class="text-small">processes and practices are in place across the portfolio to support the
                            wellbeing of the workforce.</div>
                    </div>
                </div>
                <div data-w-id="31f35ec3-e481-38be-8a67-fe2ab7512e0d" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="lightbox-item landscape-border">
                    <div class="center">
                        <div class="title-dark small" style="font-size:25px">Governance</div>
                        <center>
                            <div class="_2-red-line _2-top-border "></div>
                        </center>
                        <br>
                        <div class="text-small">good corporate governance and a code of ethics which guides our business
                            activities is the foundation of effective corporate management.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section">
        <div class="content-wrapper w-container">
            <div data-w-id="11b6766b-fb86-8016-ad26-50fea1868ee5" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="full-line bottom-border">
            </div>
            <div class="row">
                <div class="col-md-6">
                    <h2 class="title" style="font-size:25px; color:black;"> LIVE LONGER, BETTER. </h2>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    <p class="split-paragraph-green"><span class="capital-letter"></span><span class="capital-letter">W</span>hat is long-term care?
                        Long-term care is something that most people may not think they need, or might think is
                        covered by health insurance or Medicare. The fact is, if you live to be 65, there's a 70%
                        chance you'll eventually need some kind of long-term care.1 But aging isn't the only reason
                        to plan for long-term care—it's there for you if a chronic illness or disabling injury
                        prevents you from living on your own or properly caring for yourself, no matter how old you
                        are.
                        Long-term care helps with day-to-day tasks like bathing, eating, getting dressed, and
                        getting in and out of bed. And it includes care provided by nursing homes, assisted living
                        facilities, adult day care centers, hospice facilities, and skilled nurses or home health
                        aides in your (or your loved one's) home. If you're not the one who needs it, there's a good
                        chance you'll need to help care for a loved one.2 And having a long-term care plan in place
                        can help you continue to live well without sacrificing the income, investments, and savings
                        you've worked so hard for.</p>
                </div>
                <div class="col-md-6" style="display:none;">
                    <video poster="files/intro-thumbnail.png" src="files/intro.mp4" controls="" width="520" height="440"></video>
                </div>
            </div>
        </div>
    </div>
    <br><br>
    <div data-w-id="11b6766b-fb86-8016-ad26-50fea1868ee5" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="full-line bottom-border">
    </div>
    <div class="section">
        <div class="content-wrapper w-container">
            <div class="row">
                <div class="col-md-4">
                    <h3 class="title" style="font-size:22px;color:black;">Our People</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    We focus on attracting exceptionally talented people and rewarding initiative, independent thinking
                    and integrity. Our team’s breadth of skills and deep expertise are a critical source of intellectual
                    capital.
                </div>
                <div class="col-md-4">
                    <h3 class="title" style="font-size:22px; color:black;">Our Scale</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    Investing across regions, industries and asset classes gives us the knowledge, resources and
                    critical mass to take advantage of opportunities on a global scale.
                </div>
                <div class="col-md-4">
                    <h3 class="title" style="font-size:22px; color:black;">Our Performance</h3>
                    <div class="_2-red-line _2-top-border"></div>
                    <br>
                    Our performance is characterized by superior risk-adjusted returns across a broad and expanding
                    range of asset classes and through all types of economic conditions.
                </div>
            </div>
        </div>
    </div>
    <div class="content-section-3">
        <div class="content-wrapper w-container">
            <div data-w-id="0c4a9701-724f-4cf2-e1d8-07072da4b566" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="heading-container">
                <div class="flex-header">
                    <div class="_2-heading-box">
                        <div class="title">Blog</div>
                        <h2 class="h2-title">OUR latest news</h2>
                    </div>
                </div>
                <div class="_2-subheading">
                </div>
            </div>
            <div class="inner-wrapper">
                <div data-w-id="9bd52bfb-a4c2-121d-61f4-20fac82ead21" style="opacity: 1; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;" class="w-dyn-list">
                    <div role="list" class="flex-space w-dyn-items">
                        <div id="container-id"></div>
                        <!-- TradingView Widget BEGIN -->
                        <div class="tradingview-widget-container">
                            <div class="tradingview-widget-container__widget"></div>
                            <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com" rel="noopener" target="_blank"><span class="blue-text"> History</span></a> by TradingView</div>
                            <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-timeline.js" async>
                            {
                                "feedMode": "all_symbols",
                                "colorTheme": "light",
                                "isTransparent": false,
                                "displayMode": "regular",
                                "width": "100%",
                                "height": 550,
                                "locale": "en"
                            }
                            </script>
                        </div>
                        <!-- TradingView Widget END -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div data-w-id="4ec45eb7-28b0-bd6c-a6fa-f76fe3bc9f2b" class="cta-section" style="background-color: rgba(0, 0, 0, 0); background-attachment: scroll, scroll; background-image: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://vital-trade.ltd/files/bgg2g.jpeg'); background-origin: padding-box, padding-box; background-clip: border-box, border-box; background-position: center center; background-size: cover; background-repeat: no-repeat; opacity: 1; width: 100%; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg); transform-style: preserve-3d;">
        <div class="content-wrapper w-container">
            <style>
                .slider {
                    height: 400px;
                    position: relative;
                    overflow: hidden;
                    display: -webkit-box;
                    display: -webkit-flex;
                    display: -ms-flexbox;
                    display: flex;
                    -webkit-flex-flow: row nowrap;
                    -ms-flex-flow: row nowrap;
                    flex-flow: row nowrap;
                    -webkit-box-align: end;
                    -webkit-align-items: flex-end;
                    -ms-flex-align: end;
                    align-items: flex-end;
                    -webkit-box-pack: center;
                    -webkit-justify-content: center;
                    -ms-flex-pack: center;
                    justify-content: center;

                }

                .slider__nav {
                    width: 12px;
                    height: 12px;
                    margin: 3rem 12px;
                    border-radius: 50%;
                    z-index: 10;
                    outline: 6px solid #ccc;
                    outline-offset: -6px;
                    box-shadow: 0 0 0 0 #333, 0 0 0 0 rgba(51, 51, 51, 0);
                    cursor: pointer;
                    -webkit-appearance: none;
                    -moz-appearance: none;
                    appearance: none;
                    -webkit-backface-visibility: hidden;
                    backface-visibility: hidden;
                }

                .slider__nav:checked {
                    -webkit-animation: check 0.4s linear forwards;
                    animation: check 0.4s linear forwards;
                }

                .slider__nav:checked:nth-of-type(1)~.slider__inner {
                    left: 0%;
                }

                .slider__nav:checked:nth-of-type(2)~.slider__inner {
                    left: -100%;
                }

                .slider__nav:checked:nth-of-type(3)~.slider__inner {
                    left: -200%;
                }

                .slider__nav:checked:nth-of-type(4)~.slider__inner {
                    left: -300%;
                }

                .slider__inner {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 300%;
                    height: 100%;
                    -webkit-transition: left 0.4s;
                    transition: left 0.4s;
                    display: -webkit-box;
                    display: -webkit-flex;
                    display: -ms-flexbox;
                    display: flex;
                    -webkit-flex-flow: row nowrap;
                    -ms-flex-flow: row nowrap;
                    flex-flow: row nowrap;

                }

                .slider__contents {
                    height: 100%;
                    padding: 2rem;
                    text-align: center;
                    display: -webkit-box;
                    display: -webkit-flex;
                    display: -ms-flexbox;
                    display: flex;
                    -webkit-box-flex: 1;
                    -webkit-flex: 1;
                    -ms-flex: 1;
                    flex: 1;
                    -webkit-flex-flow: column nowrap;
                    -ms-flex-flow: column nowrap;
                    flex-flow: column nowrap;
                    -webkit-box-align: center;
                    -webkit-align-items: center;
                    -ms-flex-align: center;
                    align-items: center;
                    -webkit-box-pack: center;
                    -webkit-justify-content: center;
                    -ms-flex-pack: center;
                    justify-content: center;
                }

                .slider__image {
                    font-size: 2.7rem;
                    color: #FFf;
                }

                .slider__caption {
                    font-weight: 500;
                    margin: 2rem 0 1rem;
                    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
                    text-transform: uppercase;
                    color: #fff;
                }

                .slider__txt {
                    color: #fff;
                    margin-bottom: 3rem;
                    max-width: 900px;
                }

                @-webkit-keyframes check {
                    50% {
                        outline-color: #333;
                        box-shadow: 0 0 0 12px #333, 0 0 0 36px rgba(51, 51, 51, 0.2);
                    }

                    100% {
                        outline-color: #333;
                        box-shadow: 0 0 0 0 #333, 0 0 0 0 rgba(51, 51, 51, 0);
                    }
                }

                @keyframes  check {
                    50% {
                        outline-color: #333;
                        box-shadow: 0 0 0 12px #333, 0 0 0 36px rgba(51, 51, 51, 0.2);
                    }

                    100% {
                        outline-color: #333;
                        box-shadow: 0 0 0 0 #333, 0 0 0 0 rgba(51, 51, 51, 0);
                    }
                }

            </style>
            <div class="slider">
                <input type="radio" name="slider" title="slide1" checked="checked" class="slider__nav">
                <input type="radio" name="slider" title="slide2" class="slider__nav">
                <input type="radio" name="slider" title="slide3" class="slider__nav">
                <div class="slider__inner">
                    <div class="slider__contents">
                        <h2 class="slider__caption">Powering Growth</h2>
                        <p class="slider__txt">
                            <?=$sitename?> scale creates unique opportunities for revenue acceleration. Access to
                            our network of portfolio companies helps entrepreneurs grow their customer base and make
                            connections across a range of industries and geographies. An in-house team of data scientists
                            helps our companies’ management teams optimize revenue and product development opportunities. In
                            addition, our global footprint can support our companies’ expansion across the world’s major
                            economies</p>
                    </div>
                    <div class="slider__contents">
                        <h2 class="slider__caption">Scaling Efficiently</h2>
                        <p class="slider__txt">
                            We build world-class enterprises by providing companies with the resources and expertise they
                            need to scale in smart, efficient ways. Our experienced operations team helps companies optimize
                            their spending, processes, and long-term strategy, while our capital markets professionals offer
                            essential guidance on everything from IPOs and debt financing to M&amp;A.</p>
                    </div>
                    <div class="slider__contents">
                        <h2 class="slider__caption">Attracting Talent</h2>
                        <p class="slider__txt">
                            <?=$sitename?>’s network provides us with exceptional access to experienced executives
                            across industries, making it easier for portfolio companies to build effective boards and
                            operational teams. In addition, our leadership and talent development experts help companies
                            optimize their organizational design to accommodate accelerated growth.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>@media (min-width: 768px) {

        .l-section.theme-black,
        .l-section.theme-blue,
        .l-section.theme-green,
        .l-section.theme-grey,
        .l-section.theme-teal {
            padding: 6rem 0;
        }

    }

    .l-section--sm-bottom-spacing,
    .l-section.theme-black,
    .l-section.theme-blue,
    .l-section.theme-green,
    .l-section.theme-grey,
    .l-section.theme-teal {
        padding-bottom: 4.5rem;
    }

    .l-section--bottom-left-svg {
        position: relative;
        padding-bottom: 9rem !important;
    }

    @media (min-width: 768px) {
        .l-section {
            padding: 5.25rem 0;
            width: 100%;
        }

    }

    .l-section {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -ms-flex-direction: column;
        flex-direction: column;
    }

    .l-section {
        padding: 3rem 0;
        position: relative;

        margin-right: auto;
        margin-left: auto;
        width: 100%;
        z-index: 1;
    }


    .l-section.theme-black:before {
        background-color: #000;
    }

    .l-section.theme-black:before,
    .l-section.theme-blue:before,
    .l-section.theme-green:before,
    .l-section.theme-grey:before,
    .l-section.theme-teal:before {
        left: auto;
        right: unset;
    }

    .l-section.theme-black:before,
    .l-section.theme-blue:before,
    .l-section.theme-green:before,
    .l-section.theme-grey:before,
    .l-section.theme-teal:before {
        position: absolute;
        content: "";
        background-color: #f0f0f0;
        top: 0;
        bottom: 0;
        width: 100vw;
        height: 100%;
        z-index: -10;
        font-size: 0;

        right: auto;
    }

    .l-section .l-section-background {
        left: auto;
        right: unset;
    }

    .l-section .l-section-background {
        position: absolute;
        content: "";
        background-size: cover;
        top: 0;
        bottom: 0;
        width: 100vw;
        height: 100%;
        z-index: -10;

        right: auto;
    }

    .l-section.theme-black *,
    .l-section.theme-blue *,
    .l-section.theme-green *,
    .l-section.theme-teal * {
        color: #fff;
    }





    @media (min-width: 768px) {
        .l-section--bottom-left-svg:after {
            -webkit-transform: none;
            transform: none;
        }

    }

    .l-section--bottom-left-svg:after {
        content: "";
        width: 100vw;
        height: 100%;
        bottom: 0;
        left: unset;
        position: absolute;
        background-image: url("https://vital-trade.Ltd/corner-stripes-bottom.svg");
        background-position: 0 100%;
        background-repeat: no-repeat;
        z-index: -5;
        -webkit-transform: scaleY(.4);
        transform: scaleY(.4);
        -webkit-transform-origin: bottom left;
        transform-origin: bottom left;
    }


    .c-media-object {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -ms-flex-direction: column;


        -ms-flex-pack: justify;
        justify-content: space-between;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;

        width: 55%;
        margin: 0 auto 3rem;
    }
    </style>
</main>





<div class="mgm" style="display: none;">
<div class="txt" style="color:black;">Someone from <b></b> just traded with <a href="javascript:void(0);" onclick="javascript:void(0);"></a></div>
</div>

<style>
.mgm {
    border-radius: 7px;
    position: fixed;
    z-index: 90;
    bottom: 80px;
    left: 50px;
    background: #fff;
    padding: 10px 27px;
    box-shadow: 0px 5px 13px 0px rgba(0,0,0,.3);
}
.mgm a {
    font-weight: 700;
    display: block;
    color:#f2d516;
}
.mgm a, .mgm a:active {
    transition: all .2s ease;
    color:#f2d516;
}
</style>
<script data-cfasync="false" src="https://vital-trade.Ltd/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript">
var listCountries = ['United Kingdom', 'USA', 'Germany', 'France', 'Italy', 'USA', 'Australia', 'Lesotho', 'Canada', 'Argentina', 'Saudi Arabia', 'Mexico', 'Kenya', 'Maldives', 'Venezuela', 'South Africa', 'Sweden', 'India', 'South Africa', 'Italy', 'Pakistan', 'United Kingdom', 'South Africa', 'Greece', 'Cuba', 'South Africa', 'Portugal', 'Austria', 'South Africa', 'Panama', 'USA', 'South Africa', 'Netherlands', 'Switzerland', 'Belgium', 'Israel', 'Cyprus'];
    var listPlans = ['$500','$1500','$1000','$10,000','$2000','$3000','$4000', '$600', '$700', '$2500'];
    interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000);
    var run = setInterval(request, interval);

    function request() {
        clearInterval(run);
        interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000);
        var country = listCountries[Math.floor(Math.random() * listCountries.length)];
        var plan = listPlans[Math.floor(Math.random() * listPlans.length)];
        var msg = 'Someone from <b>' + country + '</b> just Withdrew <strong href="javascript:void(0);" onclick="javascript:void(0);">' + plan + ' </strong>';
        $(".mgm .txt").html(msg);
        $(".mgm").stop(true).fadeIn(2);
        window.setTimeout(function() {
            $(".mgm").stop(true).fadeOut(100);
        }, 8000);
        run = setInterval(request, interval);
    }
</script>

<div class="upper-footer">
    <div class="content-section upper-footer-1">
        <div class="content-wrapper w-container">
            <div>
                <div class="fl78222">
                    <div class="upper-footer-1-icon">
                        <img src="https://vital-trade.ltd/email.svg" class="upper-footer-1-icon" alt="For Enquiry">
                    </div>
                    <div>
                        <h4 class="title">For Enquiry</h4>
                        <p>Our agents are always online to meet with your request.</p>
                    </div>
                </div>
                <a href="?a=support" class="contact-btn">Send us a Message</a>
            </div>
        </div>
    </div>
    <div class="content-section">
        <div class="content-wrapper w-container" style="display:flex;justify-content:space-between;padding-bottom:40px;">
            <div>
                <h4 class="title">Address</h4>
                <div class="red-line"></div><br>
                <p>
                   250 Mercer St New York, NY10012 United States
                </p>
            </div>
            <!--div>
                <h4 class="title">CAll Us</h4>
                <div class="red-line"></div><br>
                <p>
                    VIP ONLY
                </p>
            </div-->
            <div>
                <h4 class="title">Email Us</h4>
                <div class="red-line"></div><br>
                <a href="?a=support" class="admin@250-mercer.ltd">admin@250-mercer.ltd</a>
            </div>
        </div>
    </div>
</div>
<footer class="footer-section" style="background:black">
    <div class="content-wrapper w-container">
        <div class="footer-form">
            <div class="" style="display:flex; justify-content:space-between;width:100%;margin-bottom:50px">
                <div class="col-md-12" style="margin-bottom: 30px;">
                    <h4 class="title" style="color:white"><a href="" class="w--current"><img src="files/logo-2.png" alt="" width="100"></a></h4>
                    <div class="red-line"></div><br>
                    <p style="color:white">
                      250-mercer.ltd is more than just finance, it’s hope for an
                        average entrepreneur to stand, evolve.
                        <div id="google_translate_element"></div>
                    </p>
                </div>
                <div class="col-md-3 col-3">
                    <h4 class="title" style="color:white">Main Services</h4>
                    <div class="red-line"></div><br>
                    <ul style="color:white">
                        <li><a href="?a=cust&page=real-estate">Real Estate</a></li>
                        <li><a href="?a=cust&page=stocks">Stock</a></li>
                        <li><a href="?a=cust&page=fixed-income">Fixed Income</a></li>
                        <li><a href="?a=cust&page=multi-asset">Multi Assets</a></li>
                        <li><a href="?a=cust&page=alternatives">Alternatives</a></li>
                    </ul>
                </div>
            </div>
            <div class="" style="display:flex; justify-content:space-between;width:100%">
                <div class="col-md-6 col-6">
                    <h4 class="title" style="color:white">Useful Links</h4>
                    <div class="red-line"></div><br>
                    <div style="display: flex">
                        <div class="col-md-6">
                            <ul style="color:white">
                                <li><a href="?a=cust&page=about-us">About Us</a></li>
                                <li><a href="?a=cust&page=responsibility">Corporate responsibility</a> </li>
                                <li><a href="?a=cust&page=financial-planning">Planning services</a></li>
                                <li><a href="?a=cust&page=support">Contact Us</a></li>
                                <li><a href="?a=faq">FAQs</a></li>
                            </ul>
                        </div>
                        <!--<div class="col-md-6">
                            <ul style="color:white">
                                <li><a target="_blank" href="certificate.pdf">CERTIFICATE OF
                                        INCORPORATION</a></li>
                            </ul>
                        </div>-->
                    </div>
                </div>
                <!--<div class="col-md-3 col-6">
                    <h4 class="title" style="color:white">Follow Us</h4>
                    <div class="red-line"></div><br>
                    <ul style="color:white">
                        <li><a href="index#">Facebook</a></li>
                        <li><a href="index#">Twitter</a></li>
                        <li><a href="index#">Instagram</a>
                        </li>
                    </ul>
                </div>-->
            </div>
        </div>
    </div>
    <div class="menu-setion">
        <div class="content-wrapper w-container">
            <div class="footer-flex">
                <p class=""> </p>
                <div class="footer-nav"><a href="?a=cust&page=about-us" class="footer-link">About Us</a><a href="?a=cust&page=terms" class="footer-link">Terms &amp; Conditions</a><a href="?a=cust&page=contact" class="footer-link">Contact
                        Us</a>
                </div>
            </div>
        </div>
        <div class="notice-section">
            <div class="content-wrapper w-container">
                <div class="notice-box">
                    <div class="notice-text">
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<script src="files/jquery-3.5.1.min.dc5e7f18c8bf79.js" type="text/javascript">
</script>
<script src="files/webflow.069902445.js" type="text/javascript"></script>
<script src="files/custom.js" type="text/javascript"></script>

     

<style type="text/css">
  
  #google_translate_element 
  {
    color: white !important;
    position: relative;
    padding: 0px;
    margin-top: 0px;

  }
  #google_translate_element a
  {
    display: none;

  }

  div.goog-te-gadget 
  {
    color :transparent;
    border: 0px solid blue;
    overflow: hidden;
    height :35px;
    position: relative;
    margin: 0px;
    
  }
  .goog-te-combo 
  {
    background: black;
    margin-top: -50px;
    position: relative;
    height :30px;
    top: 0px;
    color: white;
    padding: 5px;
    font-weight: bolder;
    font-size: x-small;
    border-radius: 5px;
    border: 1px solid white;
    
  }
  
</style>
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '237dcab3a5a02a5641a1b790c690e8845c21fa03';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>
 


</body>

</html>